import java.util.*;
class StrManipulation
{
public static void main(String[] args)
{
char chs[]={'H','U','D','H','A','A','H'};
String newStr=new String(chs);
System.out.println("\nNew String:"+newStr);


//String length
System.out.println("\n---STRING LENGTH---");
String s1="hello";
String s2="World";
System.out.println("String length of "+s1+" : "+s1.length());
System.out.println("String length of "+s2+" : "+s2.length());

//Uppercase and lowecase
System.out.println("\n---UPPERCASE AND LOWERCASE---");
System.out.println(s1+" to Upper Case : "+s1.toUpperCase());
System.out.println(s1+" to Lower Case : "+s1.toLowerCase());

//String Concatenation
System.out.println("\n---CONCATENATION OF STRING---");
System.out.println("Using concat() : "+s1.concat(s2));
System.out.println("Using + operator : "+s1+s2);

//Character position
System.out.println("\n---CHARACTER POSITION---");
System.out.println("The strings are s1=hello and s2=World");
System.out.println("Character at 3rd position : "+s1.charAt(3));
char c[]=new char[5];
s1.getChars(2,4,c,0);
System.out.println("Character between 2 and 4 : "+new String(c));

//Case comparison
System.out.println("\n---COMPARISON OF CASES---");
s1="hello";
s2="HELLO";
System.out.println("The strings are s1=hello and s2=HELLO");
System.out.println(s1+" Equals "+s2+" : "+s1.equals(s2));
System.out.println(s1+" Equals ignore case "+s2+" : "+s1.equalsIgnoreCase(s2));
System.out.println(s1+" Start with H : "+s1.startsWith("H"));
System.out.println(s1+" End with z : "+s1.startsWith("H"));
 
//Search substring
System.out.println("\n---SEARCH SUBSTRING---");
s1="just do it";
System.out.println("The string is : just do it");
System.out.println("Index of 'do' in "+s1+" is " +s1.indexOf("do"));
System.out.println("Index of 'it' in "+s1+" is " +s1.indexOf("it"));
 
//Modify string 
System.out.println("\n---MODIFY STRING---");
System.out.println("The string is : just do it");
System.out.println("Substring of "+s1+" at position 8 : " +s1.substring(8));
System.out.println("String replacing, that in place of it : "+s1.replace("it","that"));

//using valueof()
System.out.println("\n---USING valueOf()---");
float a=12.5f;
System.out.println(a+" is converted to : "+String.valueOf(a));

}
}

