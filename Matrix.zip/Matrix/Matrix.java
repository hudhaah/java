import java.util.Scanner;
class Matrix
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
System.out.print("No. of rows:");
int m=sc.nextInt();
System.out.print("No.of columns:");
int n=sc.nextInt();
int[][] matrix1=new int[m][n];
int[][] matrix2=new int[m][n];
int[][] sumMatrix=new int[m][n];

System.out.println("First matrix:");
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
matrix1[i][j]=sc.nextInt();
}
}

System.out.println("Second matrix:");
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
matrix2[i][j]=sc.nextInt();
}
}


//Addition of 2 matrix 

System.out.println("Resultant matrix:");
for(int i=0;i<m;i++)
{
for(int j=0;j<n;j++)
{
sumMatrix[i][j]=matrix1[i][j]+matrix2[i][j];
System.out.println(sumMatrix[i][j]);
}
}
}
}






